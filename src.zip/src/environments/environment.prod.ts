export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyChFo8bA3cZav7IMP2y_ovxvmNeAIsSSvg",
    authDomain: "proyecto-a6ed3.firebaseapp.com",
    projectId: "proyecto-a6ed3",
    storageBucket: "proyecto-a6ed3.firebasestorage.app",
    messagingSenderId: "338608744102",
    appId: "1:338608744102:web:1f5cf1697062f15a697667",
    measurementId: "G-J17333Y5FM"
  }
};
