import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})


export class RegisterPage {
  registroForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.registroForm = this.fb.group({
      nombre: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      contraseña: ['', [Validators.required, Validators.minLength(6)]],
      celular: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      edad: ['', [Validators.required, Validators.min(1), Validators.max(120)]],
    });
  }

  onSubmit() {
    if (this.registroForm.valid) {
      console.log('¡Gracias por registrarte! Aquí están tus datos:', this.registroForm.value);
    } else {
      alert('Por favor, complete todos los campos correctamente.');
    }
  }
}