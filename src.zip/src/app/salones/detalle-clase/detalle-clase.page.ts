import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SClasesService } from 'src/app/services/sclases.service';

@Component({
  selector: 'app-detalle-clase',
  templateUrl: './detalle-clase.page.html',
  styleUrls: ['./detalle-clase.page.scss'],
})
export class DetalleClasePage  {

  clases ={
    sigla: "",
    curso: "",
    cantidad_estudiantes: "",
    ubicacion: "",
    jornada: "",

  }


  constructor(private clasesServ:SClasesService, private router:Router) { }



  getClases(){
    this.clasesServ.getClases().subscribe(
      (resp:any) =>{
        this.clases = {
          sigla: resp[0].sigla,
          curso: resp[0].curso,
          cantidad_estudiantes: resp[0].cantidad_estudiantes,
          ubicacion: resp[0].ubicacion,
          jornada: resp[0].jornada
        }
      }
    )
  }
}
