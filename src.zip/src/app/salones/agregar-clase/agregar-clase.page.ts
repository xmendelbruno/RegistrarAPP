import { Component, OnInit } from '@angular/core';
import { IClases } from '../../interfaces/iclases';
import { SClasesService } from 'src/app/services/sclases.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agregar-clase',
  templateUrl: './agregar-clase.page.html',
  styleUrls: ['./agregar-clase.page.scss'],
})
export class AgregarClasePage implements OnInit {

  newClases:IClases ={
    sigla: "NuevaSigla",
    curso: "NuevoCurso",
    cantidad_estudiantes: "NuevaCantidad",
    ubicacion: "NuevaUbicacion",
    jornada: "NuevaJornada",

  }
  
  constructor(private clasesServ:SClasesService, private router:Router) { }

  ngOnInit() {
  }

  crearClases(){
    this.clasesServ.crearClases(this.newClases).subscribe()
    this.router.navigateByUrl("/lista-clase")
  }

}
