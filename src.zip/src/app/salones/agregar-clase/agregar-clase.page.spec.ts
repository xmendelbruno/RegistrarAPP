import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgregarClasePage } from './agregar-clase.page';

describe('AgregarClasePage', () => {
  let component: AgregarClasePage;
  let fixture: ComponentFixture<AgregarClasePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AgregarClasePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
