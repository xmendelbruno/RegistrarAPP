import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BorrarClasePageRoutingModule } from './borrar-clase-routing.module';

import { BorrarClasePage } from './borrar-clase.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BorrarClasePageRoutingModule
  ],
  declarations: [BorrarClasePage]
})
export class BorrarClasePageModule {}
