import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BorrarClasePage } from './borrar-clase.page';

const routes: Routes = [
  {
    path: '',
    component: BorrarClasePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BorrarClasePageRoutingModule {}
