import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BorrarClasePage } from './borrar-clase.page';

describe('BorrarClasePage', () => {
  let component: BorrarClasePage;
  let fixture: ComponentFixture<BorrarClasePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(BorrarClasePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
