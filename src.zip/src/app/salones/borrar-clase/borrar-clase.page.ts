import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SClasesService } from 'src/app/services/sclases.service';

@Component({
  selector: 'app-borrar-clase',
  templateUrl: './borrar-clase.page.html',
  styleUrls: ['./borrar-clase.page.scss'],
})
export class BorrarClasePage implements OnInit {

  clases ={
    sigla: "",
    curso: "",
    cantidad_estudiantes: "",
    ubicacion: "",
    jornada: "",

  }


  constructor(private router:Router, private clasesServ:SClasesService) { }

  ngOnInit() {
  }

  delateClases(){
    this.clasesServ.eliminarClases(this.clases).subscribe()
    this.router.navigateByUrl("/lista-clase")
  }

}
