import { Component, OnInit } from '@angular/core';
import { InfiniteScrollCustomEvent, LoadingController } from '@ionic/angular';
import { SClasesService } from 'src/app/services/sclases.service';

@Component({
  selector: 'app-lista-clase',
  templateUrl: './lista-clase.page.html',
  styleUrls: ['./lista-clase.page.scss'],
})
export class ListaClasePage {

  clases = [
    {sigla: "",curso: "",cantidad_estudiantes:"",ubicacion:"",jornada:""}
  ];

  constructor(private clasesServ:SClasesService, private LoadingCtrl:LoadingController) { }

 


  ionViewWillEnter(){
    this.loadClases()
  }

  async loadClases(event?: InfiniteScrollCustomEvent){
    const loading = await this.LoadingCtrl.create({
      message: "Cargando...",
      spinner: "bubbles"
    }
  );
  await loading.present();

  this.clasesServ.listarClases().subscribe(
    (resp) => {
      loading.dismiss();
      let listString = JSON.stringify(resp)
      this.clases = JSON.parse(listString)
      event?.target.complete();
    },
    (err) => {
      console.log(err.message)
      loading.dismiss();
    }
  )
  }

}
