import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListaClasePageRoutingModule } from './lista-clase-routing.module';

import { ListaClasePage } from './lista-clase.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListaClasePageRoutingModule
  ],
  declarations: [ListaClasePage]
})
export class ListaClasePageModule {}
