import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListaClasePage } from './lista-clase.page';

const routes: Routes = [
  {
    path: '',
    component: ListaClasePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListaClasePageRoutingModule {}
