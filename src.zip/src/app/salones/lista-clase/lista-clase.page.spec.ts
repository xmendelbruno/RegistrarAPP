import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListaClasePage } from './lista-clase.page';

describe('ListaClasePage', () => {
  let component: ListaClasePage;
  let fixture: ComponentFixture<ListaClasePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaClasePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
