import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActualizarClasePage } from './actualizar-clase.page';

describe('ActualizarClasePage', () => {
  let component: ActualizarClasePage;
  let fixture: ComponentFixture<ActualizarClasePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ActualizarClasePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
