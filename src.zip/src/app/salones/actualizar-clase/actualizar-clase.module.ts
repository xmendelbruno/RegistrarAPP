import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ActualizarClasePageRoutingModule } from './actualizar-clase-routing.module';

import { ActualizarClasePage } from './actualizar-clase.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActualizarClasePageRoutingModule
  ],
  declarations: [ActualizarClasePage]
})
export class ActualizarClasePageModule {}
