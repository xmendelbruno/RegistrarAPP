import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SClasesService } from 'src/app/services/sclases.service';

@Component({
  selector: 'app-actualizar-clase',
  templateUrl: './actualizar-clase.page.html',
  styleUrls: ['./actualizar-clase.page.scss'],
})
export class ActualizarClasePage {

  clases ={
    sigla: "",
    curso: "",
    cantidad_estudiantes: "",
    ubicacion: "",
    jornada: "",

  }

  constructor(private clasesServ:SClasesService, private router:Router) { }



  updateClases(){
    this.clasesServ.actualizarClases(this.clases).subscribe()
    this.router.navigateByUrl("/lista-clase")
  }

}
