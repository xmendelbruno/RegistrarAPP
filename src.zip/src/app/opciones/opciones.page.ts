import { Component, OnInit } from '@angular/core';
import { JsonplaceholderService } from '../services/jsonplaceholder.service';

@Component({
  selector: 'app-opciones',
  templateUrl: './opciones.page.html',
  styleUrls: ['./opciones.page.scss'],
})
export class OpcionesPage implements OnInit {
  
  options: any[] = [];

  constructor() { }

  async ngOnInit() {
    this.options = this.generateSystemOptions();
    console.log(this.options);
  }

  generateSystemOptions(): any[] {
    return [
      { id: 1, name: 'Tema', value: 'Oscuro', description: 'Configuración del tema de la aplicación' },
      { id: 2, name: 'Notificaciones', value: 'Activadas', description: 'Estado de las notificaciones' },
      { id: 3, name: 'Idioma', value: 'Español', description: 'Idioma de la aplicación' },
      { id: 4, name: 'Ubicación', value: 'Permitida', description: 'Permiso para usar la ubicación' },
      { id: 5, name: 'Sincronización', value: 'Automática', description: 'Estado de la sincronización de datos' },
    ];
  }
}
