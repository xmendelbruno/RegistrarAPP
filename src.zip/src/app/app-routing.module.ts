import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./users/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./users/register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'restablecer',
    loadChildren: () => import('./users/restablecer/restablecer.module').then( m => m.RestablecerPageModule)
  },
  {
    path: 'inicio',
    loadChildren: () => import('./inicio/inicio.module').then( m => m.InicioPageModule)
  },
  {
    path: 'perfil',
    loadChildren: () => import('./users/perfil/perfil.module').then( m => m.PerfilPageModule)
  },
  {
    path: 'agregar-clase',
    loadChildren: () => import('./salones/agregar-clase/agregar-clase.module').then( m => m.AgregarClasePageModule)
  },
  {
    path: 'borrar-clase',
    loadChildren: () => import('./salones/borrar-clase/borrar-clase.module').then( m => m.BorrarClasePageModule)
  },
  {
    path: 'detalle-clase',
    loadChildren: () => import('./salones/detalle-clase/detalle-clase.module').then( m => m.DetalleClasePageModule)
  },
  {
    path: 'lista-clase',
    loadChildren: () => import('./salones/lista-clase/lista-clase.module').then( m => m.ListaClasePageModule)
  },
  {
    path: 'actualizar-clase',
    loadChildren: () => import('./salones/actualizar-clase/actualizar-clase.module').then( m => m.ActualizarClasePageModule)
  },
  {
    path: 'opciones',
    loadChildren: () => import('./opciones/opciones.module').then( m => m.OpcionesPageModule)
  },
  {
    path: 'generarqr',
    loadChildren: () => import('./generarqr/generarqr.module').then( m => m.GenerarqrPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
