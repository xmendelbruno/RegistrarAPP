export interface IClases {
    sigla: String,
	curso: String,
	cantidad_estudiantes: String,
	ubicacion: String,
	jornada: String
}
