import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IClases } from '../interfaces/iclases';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class SClasesService {

  constructor(private http:HttpClient) { }

  listarClases():Observable<IClases>{
    return this.http.get<IClases>(`${environment.apiUrl}/clases`)
    
  }

  crearClases(newClases:IClases):Observable<IClases>{
    return this.http.post<IClases>(`${environment.apiUrl}/clases`, newClases)
    
  }
  getClases():Observable<IClases>{
    return this.http.get<IClases>(`${environment.apiUrl}/clases`)
  }

  actualizarClases(clases:any):Observable<IClases>{
    return this.http.put<IClases>(`${environment.apiUrl}/clases`,clases)
  }

  eliminarClases(clases:any):Observable<IClases>{
    return this.http.delete<IClases>(`${environment.apiUrl}/clases`)
  }
}
