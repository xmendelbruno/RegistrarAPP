import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class JsonplaceholderService {
  
  private API_URL = 'https://jsonplaceholder.typicode.com';

  constructor() { }

  async getPosts(){
    const response = await axios.get(`${this.API_URL}/posts`)
    return response.data;
  }

  async getPost(id: number){
    const response = await axios.get(`${this.API_URL}/posts/$`)
    return response.data;
  }
}