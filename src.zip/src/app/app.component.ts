import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    {tittle: 'Login', url: 'users/login',icon:'log-in'},
    {tittle: 'Register', url: 'users/register',icon:'log-in'},
    {tittle: 'Restablecer', url: 'users/restablecer',icon:'resize'},
    {tittle: 'Inicio', url: 'inicio',icon:'home'},
    {tittle: 'Perfil', url: 'users/perfil',icon:'log-in'},
    {tittle: 'Actualizar-clase', url: 'actualizar-clase',icon:'log-in'},
    {tittle: 'Agregar-clase', url: 'agregar-clase',icon:'log-in'},
    {tittle: 'Borrar-clase', url: 'borrar-clase',icon:'log-in'},
    {tittle: 'Lista-clase', url: 'lista-clase',icon:'log-in'},
    

  ];
  
}










