import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FirestoreService {

  constructor(private firestore:AngularFirestore) {}


  getCursos(): Observable<any[]> {
    return this.firestore.collection('cursos').valueChanges();
  }

  addCurso(curso: any): Promise<void> {
    const id = this.firestore.createId();  
    return this.firestore.collection('cursos').doc(id).set(curso);
  }

  updateCurso(id: string, curso: any): Promise<void> {
    return this.firestore.collection('cursos').doc(id).update(curso);
  }

  
  deleteCurso(id: string): Promise<void> {
    return this.firestore.collection('cursos').doc(id).delete();
  }
}