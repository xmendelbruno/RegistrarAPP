import { Component, OnInit } from '@angular/core';
import * as QRCode from 'qrcode';
@Component({
  selector: 'app-generarqr',
  templateUrl: './generarqr.page.html',
  styleUrls: ['./generarqr.page.scss'],
})
export class GenerarqrPage implements OnInit {
  texto: any;  
  qrCodeUrl: string = ''; 

  constructor() { }

  ngOnInit() {
  }

  generarQRCode() {
    // Si el texto es proporcionado, generar el QR
    if (this.texto) {
      QRCode.toDataURL(this.texto, { width: 400 }, (err: any, url: string) => {
        if (err) {
          console.error('Error al generar el QR', err);
        } else {
          this.qrCodeUrl = url;  // Guardar la URL generada en una propiedad
        }
      });
    } else {
      console.log('Por favor, ingresa un texto para generar el código QR');
    }
  }

}
